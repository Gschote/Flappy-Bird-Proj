using Unity.VisualScripting;
using UnityEngine;

public class GameoverManager : MonoBehaviour
{
    [SerializeField] private GameObject GameoverScreen;
    private bool isStarted = false;

    private void Awake()
    {
        GameoverScreen.SetActive(false);
        Time.timeScale = 0f;
    }

    private void Update()
    {
        if (OnCollisionEnter(Collider2D ))
        {
            GameoverScreen.SetActive(true);
            isStarted = true;
            Time.timeScale = 1f;
        }
    }
   
}
